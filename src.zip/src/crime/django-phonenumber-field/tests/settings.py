DATABASES = {"default": {"ENGINE": "django.db.backends.sqlite3"}}

SECRET_KEY = "secrekey"

INSTALLED_APPS = ["phonenumber_field", "tests"]
