from django.apps import AppConfig


class CriminalConfig(AppConfig):
    name = 'Criminal'
