from django.contrib import admin

from .models import Criminal
# Register your models here.

admin.site.register(Criminal)
