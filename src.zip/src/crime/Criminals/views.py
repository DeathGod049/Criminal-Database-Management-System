from django.shortcuts import render,get_object_or_404,redirect,HttpResponseRedirect
from django.http import Http404
from django.core.files.storage import FileSystemStorage
from django.db.models import Q

from .models import Criminal
from .forms import CriminalForm
# Create your views here.

def CriminalListView(request):
	query = request.GET.get("Search" , None)
	queryset=Criminal.objects.all()	#list of objects
	if query is not None:
		queryset = queryset.filter(Q(First_name__icontains = query) | Q(id__icontains = query) | Q(Last_name__icontains = query))

	context={
			"object_list" : queryset
	}
	return render(request,'criminal/Criminal_list.html',context)

#Function to dynamically render model values with update function
def dynamic_lookup_view(request,id):
	#obj=Product.objects.get(id=my_id)
	#obj=get_object_or_404(Product,id=my_id)
	try:
		obj=Criminal.objects.get(id=id)
	except:
		raise Http404

	context={
			"object" : obj
	}
	return render(request,'criminal/Criminal_details.html',context)

def Criminal_create_view(request):
	if request.method == 'POST':
		form = CriminalForm(request.POST or None, request.FILES)
		if form.is_valid():
			form.save()
			return redirect('../')
	else:
		form = CriminalForm()

	context = {
			"form" : form
	}
	return render(request,'criminal/Criminal_create.html',context)

def Criminal_update_view(request,id=id):
	obj=get_object_or_404(Criminal,id=id)
	if request.method == 'POST':
		form=CriminalForm(request.POST or None,request.FILES , instance=obj)
		if form.is_valid():
			form.save()
			return HttpResponseRedirect('../details/')
	else:
		form = CriminalForm(instance = obj)

	context={
			"form" : form
	}
	return render(request,'criminal/Criminal_create.html',context)

def Criminal_delete_view(request,id):
	obj = get_object_or_404(Criminal,id=id)
	if request.method == "POST":	#'POST' posts the data into model and 'GET' gets the data from queryset(model)
		obj.delete()
		return redirect('../../Criminals/')  #Redirects page

	context={
			"object" : obj
	}
	return render(request,'criminal/Criminal_delete.html',context)

def Criminals_home_view(request):
	return render(request,'criminal/Criminal_home.html',{})

#Function to just view the details
def dynamic_lookup_just_view(request,id):
	#obj=Product.objects.get(id=my_id)
	#obj=get_object_or_404(Product,id=my_id)
	try:
		obj=Criminal.objects.get(id=id)
	except:
		raise Http404

	context={
			"object" : obj
	}
	return render(request,'criminal/Criminal_just_details.html',context)

def Criminals_multiple_delete_view(request,*args,**kwargs):
	queryset = Criminal.objects.all()
	ids = request.POST.getlist('_selected_action') #gets the ids of the records
	
	context ={
			"object_list" : queryset
	}
	context1 = {
			"object" : ids
	}
	return render(request,'criminal/Criminal_multi_delete.html',context,context1)
