from django.db import models
from datetime import date,datetime
from django.urls import reverse
from django.core.validators import MinValueValidator, MaxValueValidator
from phonenumber_field.modelfields import PhoneNumberField

class Criminal(models.Model):

	First_name       = models.CharField(max_length = 100)
	Last_name        = models.CharField(max_length = 100)
	face_front_image = models.ImageField(upload_to='pictures/%y/%m/%d/', height_field=None, width_field=None, max_length=100, blank = True, null = True)
	face_side_image  = models.ImageField(upload_to='pictures/%y/%m/%d/', height_field=None, width_field=None, max_length=100, blank = True, null = True)
	email	   	     = models.EmailField(max_length = 50, blank = True , null = True)

	GENDER_CHOICES = (
   					('Male', 'Male'),
   					('Female', 'Female')
	)
	gender	       			= models.CharField(choices = GENDER_CHOICES, max_length = 10)
	age			   			= models.SmallIntegerField()
	height   				= models.DecimalField(max_digits = 6 , decimal_places = 2)
	weight     				= models.DecimalField(max_digits = 6 , decimal_places = 2)
	phone_number   			= PhoneNumberField(null=True , blank=True)
	Address		   			= models.TextField(blank = True , null = True)
	description_of_criminal = models.TextField(blank = True , null = True)
	
	organisation_attached_with = models.TextField(blank = True , null = True)

	CRIME_TYPE = (
				('Assault', 'Assault'),
				('Kidnapping', 'Kidnapping'),
				('Robbery', 'Robbery'),
				('Burglary', 'Burglary'),
				('Forgery', 'Forgery'),
				('Rape', 'Rape'),
				('Homicide', 'Homicide'),
				('False Imprisonment', 'False Imprisonment'),
				('Solicitation', 'Solicitation'),
				('Conspiracy', 'Conspiracy'),
				('Drunk Driving', 'Drunk Driving')
	)
	type_of_crime  			= models.CharField(choices = CRIME_TYPE,max_length = 50)
	crime_numbers  			= models.IntegerField(blank = True, null = True)
	date_of_crime  			= models.DateField(auto_now = False, auto_now_add = False)
	time_of_crime  			= models.TimeField(auto_now = False, auto_now_add = False)
	place_of_crime 			= models.CharField(max_length = 100)
	brief_details_of_crime  = models.TextField()

	Status_of_the_case = (
						('FIR Lodged', 'FIR Lodged'),
						('Handed Over to Corresponding P.S', 'Handed Over to Corresponding P.S'),
						('Under Investigation', 'Under Investigation'),
						('Analyzing Ongoing', 'Analyzing Ongoing'),
						('Chargesheet Generation Ongoing', 'Chargesheet Generation Ongoing'),
						('Hearing Done by Corresponding Court', 'Hearing Done by Corresponding Court'),
						('Sentenced', 'Sentenced'),
						('Case Closed', 'Case Closed')
	)
	status_of_the_case 	= models.CharField(choices = Status_of_the_case , max_length = 60)	
	police_station      = models.CharField(max_length = 100)
	Address_of_police_station = models.TextField()
	FIR_lodged_by       = models.CharField(max_length = 100)
	criminal_taken_under_police_station = models.CharField(max_length = 100)
	address_of_the_criminal_taken_under_police_station = models.TextField(blank = True, null =True)
	charged_under_IPC 	= models.CharField(max_length = 50)
	investigating_by	= models.CharField(max_length = 50)
	evidence	   		= models.FileField(upload_to = 'files/%y/%m/%d/', max_length = 100, blank = True, null=True)
	Authentication_Key  = models.IntegerField(help_text = "Enter the Authentication Key",validators = [MinValueValidator(379,message = 'Enter Valid Key') , MaxValueValidator(379,message = 'Enter a Valid Key')])



	def dynamic_url_link(self):
		return reverse("Criminals:Criminal_Detail_view" , kwargs = {"id" : self.id})   #f'//{self.id}/update/'

	def update_url_link(self):
		return reverse("Criminals:Criminal-Update-View" , kwargs = {"id" : self.id})

	def delete_url_link(self):
		return reverse("Criminals:Criminal-Delete-View" , kwargs = {"id" : self.id})

	def dynamic_url_link_view(self):
		return reverse("Criminals:Criminal-Multiple-Delete-view" , kwargs = {"id" : self.id})

	# def add_url_link(self):
	# 	return reverse("Criminals:Criminal-Create-View")




