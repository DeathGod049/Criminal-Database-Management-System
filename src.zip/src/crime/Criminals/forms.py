from django import forms
from django.core.exceptions import ValidationError
from django.core.validators import *
from phonenumber_field.formfields import PhoneNumberField

from .models import Criminal

class DateInput(forms.DateInput):
	input_type = 'date'

class TimeInput(forms.TimeInput):
	input_type = 'time'

class CriminalForm(forms.ModelForm):
	First_name = forms.CharField(widget = forms.TextInput(attrs = {"placeholder" : 'Criminal First Name'}))
	Last_name  = forms.CharField(widget = forms.TextInput(attrs = {"placeholder" : 'Criminal Last Name'}))
	email	   = forms.EmailField(required = False , validators = [validate_email])
	age		   = forms.IntegerField(required = True , widget = forms.NumberInput(attrs = {"placeholder" : 'Criminal Age'}))
	height	   = forms.DecimalField(widget = forms.NumberInput(attrs = {"placeholder" : 'Criminal Height'}))
	weight     = forms.DecimalField(widget = forms.NumberInput(attrs = {"placeholder" : 'Criminal Weight'}))
	phone_number = PhoneNumberField(required = False)
	Address    = forms.CharField(widget = forms.Textarea(attrs = {"placeholder" : 'Criminal Address' , "rows" : 10 , "cols" : 50}))
	evidence   = forms.FileField(required = False ,widget = forms.ClearableFileInput(attrs = {'multiple': True}))
	Authentication_Key = forms.IntegerField(
											required = True,
											label = 'Authentication Key' ,
											widget = forms.NumberInput(
												attrs = 
														{"placeholder" : 'Authentication Key'}
													)
											)

	class Meta:
		model = Criminal
		fields = '__all__'
		widgets = {
				'date_of_crime' : DateInput(),
				'time_of_crime' : TimeInput(),
		}