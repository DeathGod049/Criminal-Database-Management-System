from django.urls import path
from .views import *

app_name = 'Criminals'
urlpatterns = [
			path('',Criminals_home_view,name='Criminals-home-view'),
			path('Criminals/',CriminalListView,name='Criminal-List-View'),
			path('<int:id>/details/',dynamic_lookup_view,name='Criminal_Detail_view'),
			path('create/',Criminal_create_view,name='Criminal-Create-View'),
			path('<int:id>/update/',Criminal_update_view,name='Criminal-Update-View'),
			path('<int:id>/delete/',Criminal_delete_view,name='Criminal-Delete-View'),
			path('Criminals/multidelete/',Criminals_multiple_delete_view,name='Criminal-Multiple-Delete'),
			path('Criminals/multidelete/<int:id>/details/',dynamic_lookup_just_view,name='Criminal-Multiple-Delete-view')
]

